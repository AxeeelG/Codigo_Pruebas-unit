const calculator = require('./calculator.js').default;

test('adds 1 + 2 to equal 3', () => {
  expect(calculator.add(1, 2)).toBe(3);
});

test('adds -4 + 8 to equal 4', () => {
  expect(calculator.add(-4, 8)).toBe(4);
});

test('subtract 5 - 4 to equal 1', () => {
  expect(calculator.subtract(5, 4)).toBe(1);
});

test('subtract -5 - -10 to equal 5', () => {
  expect(calculator.subtract(-5, -10)).toBe(5);
});

test('divides 12 by 3 to equal 4', () => {
  expect(calculator.divide(12, 3)).toBe(4);
});

test('divides -12 by 3 to equal -4', () => {
  expect(calculator.divide(-12, 3)).toBe(-4);
});

test('throws an error when dividing by zero', () => {
  expect(() => calculator.divide(12, 0)).toThrow(RangeError);
});

test('multiplies 4 by 3 to equal 12', () => {
  expect(calculator.multiply(4, 3)).toBe(12);
});

test('multiplies -4 by 3 to equal -12', () => {
  expect(calculator.multiply(-4, 3)).toBe(-12);
});

const {
  promedio,
  factorial,
  sumaNaturales,
  formulaGeneral
} = require('./js/calculator/calculator.js');

describe('Promedio', () => {

  test('Promedio de tres números', () => {
    expect(promedio([10, 20, 30])).toBe(20);
  });

  test('Promedio de dos números', () => {
    expect(promedio([5, 15])).toBe(10);
  });

});

describe('Factorial', () => {

  test('Factorial de 5', () => {
    expect(factorial(5)).toBe(120);
  });

  test('Factorial de 0', () => {
    expect(factorial(0)).toBe(1);
  });

});

describe('Suma de números naturales', () => {

  test('Suma hasta 5', () => {
    expect(sumaNaturales(5)).toBe(15);
  });

  test('Suma hasta 10', () => {
    expect(sumaNaturales(10)).toBe(55);
  });

});

describe('Fórmula General', () => {

  test('x² - 5x + 6 = 0', () => {
    expect(formulaGeneral(1, -5, 6))
      .toEqual({
        x1: 3,
        x2: 2
      });
  });

  test('x² - 3x + 2 = 0', () => {
    expect(formulaGeneral(1, -3, 2))
      .toEqual({
        x1: 2,
        x2: 1
      });
  });

});
