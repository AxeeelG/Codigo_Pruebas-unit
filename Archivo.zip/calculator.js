const add = function(a, b) {
    return a + b;
}
const subtract = function(a, b) {
  return a - b;
}

function divide(a, b){
  if (b === 0) {
    throw new RangeError('Cannot divide by zero');
  }
  return a / b;
}

function multiply(a, b){
  return a * b;
}



import calculator from './js/calculator/calculator.js';
// PROMEDIO
function promedio(numeros) {
  let suma = 0;

  for (let i = 0; i < numeros.length; i++) {
    suma += numeros[i];
  }

  return suma / numeros.length;
}

// FACTORIAL
function factorial(n) {
  let resultado = 1;

  for (let i = 1; i <= n; i++) {
    resultado *= i;
  }

  return resultado;
}

// SUMA DE LOS PRIMEROS NÚMEROS NATURALES
function sumaNaturales(n) {
  let suma = 0;

  for (let i = 1; i <= n; i++) {
    suma += i;
  }

  return suma;
}

// FÓRMULA GENERAL (CHICHARRONERA)
function formulaGeneral(a, b, c) {
  const discriminante = (b * b) - (4 * a * c);

  const x1 = (-b + Math.sqrt(discriminante)) / (2 * a);
  const x2 = (-b - Math.sqrt(discriminante)) / (2 * a);

  return {
    x1,
    x2
  };
}

export default {
  promedio,
  factorial,
  sumaNaturales,
  formulaGeneral
};
