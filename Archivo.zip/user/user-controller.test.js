const UserController = require("./user-controller");
const User = require("./user");

test('add adds a user that is not already in the list', () => {
  const userController = new UserController();
  const user = new User(1234, "Santiago", "santiago@generation.org");

  expect(userController.getUsers()).not.toContain(user);
  userController.add(user);

  expect(userController.getUsers()).toContain(user);
});

test('remove leaves the list unchanged when the user is not in it', () => {
  const userController = new UserController();
  const existingUser = new User(1234, "Santiago", "santiago@generation.org");
  const absentUser = new User(5678, "Alex", "alex@generation.org");
  userController.add(existingUser);

  userController.remove(absentUser);

  expect(userController.getUsers()).toEqual([existingUser]);
});

test('findByEmail returns the user with the matching email', () => {
  const userController = new UserController();
  const user = new User(1234, "Santiago", "santiago@generation.org");
  userController.add(user);

  expect(userController.findByEmail("santiago@generation.org")).toBe(user);
});

test('findByEmail returns undefined when no email matches', () => {
  const userController = new UserController();
  userController.add(new User(1234, "Santiago", "santiago@generation.org"));

  expect(userController.findByEmail("missing@generation.org")).toBeUndefined();
});

test('findById returns the user with the matching id', () => {
  const userController = new UserController();
  const user = new User(1234, "Santiago", "santiago@generation.org");
  userController.add(user);

  expect(userController.findById(1234)).toBe(user);
});

test('findById returns undefined when no id matches', () => {
  const userController = new UserController();
  userController.add(new User(1234, "Santiago", "santiago@generation.org"));

  expect(userController.findById(5678)).toBeUndefined();
});
