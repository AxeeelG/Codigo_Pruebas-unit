const User = require("./user");

test('stores and returns the user id, name, and email', () => {
  const user = new User(1234, "Santiago", "santiago@generation.org");

  expect(user.getId()).toBe(1234);
  expect(user.getName()).toBe("Santiago");
  expect(user.getEmail()).toBe("santiago@generation.org");
});

test('equalsTo compares users by id', () => {
  const user = new User(1234, "Santiago", "santiago@generation.org");

  expect(user.equalsTo(new User(1234, "Another name", "another@generation.org"))).toBe(true);
  expect(user.equalsTo(new User(5678, "Alex", "alex@generation.org"))).toBe(false);
});
